# ROADMAP

Live checklist. Check a box when the work is real and merged — not when it's started. Expands
`Roofsteel-Ecommerce-Platform-Specification.docx` Section 6.3 into concrete, checkable tasks.
Update this file as part of every PR that completes a task (see `AGENTS.md` Section 3).

Status legend: `[x]` done and merged, `[~]` in progress, `[ ]` not started

---

## Phase 1 — Foundation

- [x] Monorepo structure (apps/web, apps/api, apps/ai-service, packages/shared-types)
- [x] Prisma schema — full data model (catalogue, pricing, accounts, orders, quotes, wishlists, compliance docs)
- [x] Seed script + real catalogue/pricing data export (171 products, 15 pricing bands)
- [x] Pricing engine service — real tier-resolution logic
- [x] Products listing/filtering — real logic
- [x] CI pipeline, .env.example, LoC-check script and history log
- [x] AGENTS.md, CLAUDE.md, ROADMAP.md, docs/DEVELOPMENT-LOG.md, docs/DECISIONS.md
- [ ] npm install verified working with real network access (first Claude Code / OpenHands session)
- [ ] Real Postgres + Redis provisioned (Render), first successful prisma migrate + prisma db seed against a live database

## Phase 2 — Product, Catalogue & Pricing

- [~] Auth module — registration, login done (real bcrypt hashing). Session/JWT issuance still open.
- [ ] Account-type resolution wired into ProductsService/PricingService (replacing the current RETAIL-only default)
- [ ] Real Postgres full-text search (tsvector/pg_trgm), replacing the contains filter placeholder
- [x] Categories endpoint — GET /v1/categories, real, built in Gap Analysis I session
- [~] Category/subcategory browse pages (web) — route scaffolded (app/category/[slug]/page.tsx), not yet built out; Home page's CategoryGrid still on fixture data pending real fetch wiring
- [~] Product detail page — real layout + PriceDisplay + FulfilmentBadge done; gallery is a placeholder, accordion specs/compliance tab not yet wired to real data
- [x] Made-to-Length Configurator (spec 4.1) — real frontend UI, real validation, real live pricing matching the backend formula exactly. Only the actual fetch to POST /v1/cart/items is untested against a live API.
- [ ] Real Postgres full-text search — see Gap Analysis I Section 8; still a `contains` placeholder
- [ ] Session/JWT issuance — see Gap Analysis I Section 7, priority #2
- [ ] Address, Quote/RFQ, Wishlist, ComplianceDocument endpoints — zero coverage, see Gap Analysis I Section 2
- [ ] Review/Rating data model — doesn't exist yet in schema.prisma, see Gap Analysis I Section 3
- [ ] First real test file (pricing.service.spec.ts) — see Gap Analysis I Section 6, zero test coverage currently
- [x] All 21 missing storefront routes scaffolded (login, register, cart, checkout ×3, account ×6, trade/apply, quote/request, category/[slug], search, 5 legal pages) — see docs/GAP-ANALYSIS-I.md Section 1 and 5
- [ ] Cut/bend service selector (spec 4.4) — SANS 282 shape codes

## Phase 3 — Transactional Layer

- [~] Cart module — add/update/remove/merge done. Frontend UI still open.
- [ ] One-page checkout flow (frontend — backend order creation already real, see orders.service.ts)
- [~] PayFast integration — real signature logic (both algorithms) done. Live HTTP calls to PayFast still open.
- [x] Estimated ready timing for mixed-fulfilment orders (ADR-014) — Order.estimatedReadyDays, computed as max lead time across lines
- [x] Non-returnable policy enforcement groundwork (ADR-015) — OrderItem.fulfilmentType snapshot, ready for the Returns/RMA module to check against
- [ ] Multi-shipment/split checkout for mixed carts — deferred, real mechanism identified (reuse Bellwether SWE Plumbers' cartItemIds subset-scoping pattern) but not built
- [~] Lulapay integration — Partner onboarding approved (ADR-006), strategy class scaffolded honestly (throws until LULAPAY_API_KEY exists). Real API contract still open.
- [~] PayJustNow integration — Retail tier only. Same status as Lulapay.
- [x] Trade account application flow (PENDING/APPROVED/REJECTED) — real logic, single-transaction approval
- [ ] Quote/RFQ engine — Project/Tender tier

## Phase 4 — Operational Layer

- [x] Inventory schema — StockLevel, StockMovement, Location, Product.leadTimeDays (real, built in the Listings/CMS/Inventory session) — see guidelines/13-listings-cms-inventory-sales.md
- [x] Product content schema — Product.description, ProductImage (real, same session)
- [ ] Image/document storage decision — S3-compatible vs. Render-native — ADR-013, open, blocks admin upload feature
- [ ] Admin panel — products (incl. content/image editing), orders, trade accounts, pricing bands (editable, mirroring the workbook's yellow-cell convention), stock levels/movements
- [ ] Stock reservation logic — qtyReserved increments on real order placement, not cart add (guidelines/13 Section 3.1)
- [ ] Order lifecycle states + BullMQ notification jobs (email/SMS)
- [ ] Compliance document attachment — mill certs, NRCS LoAs (spec 4.5) — endpoints still needed, see Gap Analysis I Section 2
- [x] Freight/weight-banded delivery calculator — 7 provinces (spec 4.6) — real weight + distance-multiplier structure built (ADR-016); rand values still illustrative, no rate-card review yet
- [ ] Courier selection — Besfleet vs. external parcel courier vs. both by weight band (ADR-017, open decision)
- [ ] Shipment/tracking integration — schema-ready (Shipment model), blocked on courier decision above
- [ ] Location-detection UI (province pre-fill via browser geolocation, always customer-confirmable) — guidelines/15 Section 1, build alongside the real checkout page
- [ ] Back-in-stock / low-stock alerts — real data to trigger from now exists (StockLevel), logic itself not yet built
- [ ] Sales/revenue reporting dashboard — by period, category, customer tier (guidelines/13 Section 6)
- [ ] Cost-refinement pass — landed costs against real supplier quotes (ADR-007), category by category, starting with the ones running highest
- [ ] Real physical stock count — the seeded StockLevel quantities (100 units flat per Stock product) are illustrative placeholder data, NOT reviewed/approved — see guidelines/13 Section 3.1 and the seed.ts comment

## Phase 5 — Launch Polish

- [ ] Legal/info pages (Terms, Privacy, Returns, Shipping, FAQ)
- [ ] Accessibility pass — WCAG 2.1 AA (mirroring the corporate site's existing standard)
- [ ] ai-service quote-assist endpoint
- [ ] Wishlist — multi-list, project-based
- [ ] Reviews — text/star (photo upload: see spec Section 8 open question)
- [ ] SEO pass
- [ ] First gap-analysis review (post-launch, matching the Bellwether SWE Plumbers pattern)

---

## Resolved decisions

See docs/DECISIONS.md ADR-005, ADR-006, ADR-007 for full reasoning. As of 2026-08-09:

- ~~Repository ownership~~ — Besbpo Group (ADR-005)
- ~~Lulapay Partner onboarding~~ — approved, proceeding (ADR-006)
- ~~Real landed costs~~ — approved for use now, cost-refinement pass planned for Phase 4/5 (ADR-007)

## Still blocked / waiting on a decision

- Click-and-collect timing (build now vs. defer to real yard opening)
- Reviews: photo upload in v1 scope or not
